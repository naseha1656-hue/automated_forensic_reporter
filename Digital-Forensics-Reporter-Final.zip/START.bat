@echo off
title AUTOPSY SIM
color 0A
cls

echo.
echo  AUTOPSY SIM -- Digital Forensics Bureau
echo  ----------------------------------------
echo.

set "BACKEND=%~dp0backend"
set "SPLASH=%~dp0frontend\loading.html"
set "RUNNER=%TEMP%\autopsy_run.py"

if not exist "%BACKEND%\main.py" (
  echo  ERROR: Cannot find backend\main.py
  pause & exit /b 1
)

if not exist "%BACKEND%\.env" (
  echo GROQ_API_KEY=> "%BACKEND%\.env"
  echo OPENAI_API_KEY=>> "%BACKEND%\.env"
)

if not exist "%BACKEND%\.installed" (
  echo  Installing dependencies, please wait...
  cd /d "%BACKEND%"
  pip install fastapi "uvicorn[standard]" python-multipart groq openai==1.14.0 httpx==0.27.0 reportlab python-dotenv cryptography bcrypt -q --disable-pip-version-check
  if %errorlevel% neq 0 ( echo  ERROR: Install failed. & pause & exit /b 1 )
  echo installed > "%BACKEND%\.installed"
  echo  Done.
  echo.
)

for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":8000 "') do taskkill /PID %%a /F >nul 2>&1
timeout /t 1 /nobreak >nul

(
echo import sys, threading, time, webbrowser, uvicorn
echo sys.path.insert^(0, r'%BACKEND%'^)
echo from main import app
echo SPLASH = r'%SPLASH%'
echo def launch^(^):
echo     time.sleep^(0.3^)
echo     webbrowser.open^('file:///' + SPLASH.replace^('\\', '/'^)^)
echo threading.Thread^(target=launch, daemon=True^).start^(^)
echo try:
echo     uvicorn.run^(app, host='0.0.0.0', port=8000^)
echo except ^(KeyboardInterrupt, SystemExit^): pass
echo print^(""^)
echo print^("Server stopped. You can close this window."^)
) > "%RUNNER%"

echo  Starting server...
echo  Keep this window open. Press CTRL+C to stop.
echo.

cd /d "%BACKEND%"
python "%RUNNER%"

echo.
echo  Stopped. Press any key to close.
pause > nul
