"""
Automated Digital Forensics Reporter - Backend API
"""

from fastapi import FastAPI, UploadFile, File, Form, HTTPException, BackgroundTasks, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn
import os
import json
import uuid
from datetime import datetime
from pathlib import Path
from dotenv import load_dotenv
from pathlib import Path

# Load .env using absolute path so it always works
ENV_PATH = Path(__file__).parent / ".env"
load_dotenv(dotenv_path=ENV_PATH, override=True)

from rag_engine import ForensicsRAGEngine
from report_generator import ReportGenerator
from autopsy_parser import AutopsyParser

app = FastAPI(title="Automated Digital Forensics Reporter", version="2.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

ROOT_DIR = Path(__file__).parent.parent  # project root (one level above backend/)
UPLOAD_DIR = Path("uploads")
REPORTS_DIR = Path("reports")
UPLOAD_DIR.mkdir(exist_ok=True)
REPORTS_DIR.mkdir(exist_ok=True)

jobs = {}
job_audit = {}  # job_id -> list of audit entries for that job

def _job_audit(job_id: str, user: str, action: str, detail: str = ""):
    """Log an audit event tied to a specific job."""
    entry = {
        "timestamp": datetime.now().isoformat(),
        "user":      user or "anonymous",
        "action":    action,
        "detail":    detail,
    }
    if job_id not in job_audit:
        job_audit[job_id] = []
    job_audit[job_id].append(entry)
    _audit(user, action, f"job={job_id} | {detail}")


# ── AUDIT LOG ─────────────────────────────────────────────────────────────
import threading as _threading
_audit_lock = _threading.Lock()
_audit_log = []  # in-memory audit trail

def _audit(user: str, action: str, detail: str = ""):
    entry = {
        "timestamp": datetime.now().isoformat(),
        "user":      user or "anonymous",
        "action":    action,
        "detail":    detail,
    }
    with _audit_lock:
        _audit_log.append(entry)
        if len(_audit_log) > 1000:
            _audit_log.pop(0)
    print(f"[AUDIT] {entry['timestamp']} | {entry['user']} | {entry['action']} | {entry['detail']}")

# ── SESSION API KEY STORE ─────────────────────────────────────────────────
# Keys are stored ONLY in memory, never logged, never written to disk.
# Each session token maps to an encrypted key + expiry time.
import hashlib, time, secrets as _secrets
from cryptography.fernet import Fernet

_SESSION_KEYS = {}   # session_token -> {fernet_key, encrypted_api_key, expires_at, key_type}
_SESSION_TIMEOUT = 1800  # 30 minutes inactivity

def _make_fernet():
    return Fernet(Fernet.generate_key())

def _store_session_key(session_token: str, api_key: str, key_type: str):
    f = _make_fernet()
    encrypted = f.encrypt(api_key.encode()).decode()
    _SESSION_KEYS[session_token] = {
        "fernet": f,
        "encrypted": encrypted,
        "expires_at": time.time() + _SESSION_TIMEOUT,
        "key_type": key_type,
    }

def _get_session_key(session_token: str):
    entry = _SESSION_KEYS.get(session_token)
    if not entry:
        return None, None
    if time.time() > entry["expires_at"]:
        del _SESSION_KEYS[session_token]
        return None, None
    # Refresh expiry on use
    entry["expires_at"] = time.time() + _SESSION_TIMEOUT
    try:
        key = entry["fernet"].decrypt(entry["encrypted"].encode()).decode()
        return key, entry["key_type"]
    except Exception:
        return None, None

def _clear_session_key(session_token: str):
    _SESSION_KEYS.pop(session_token, None)

def _purge_expired_keys():
    now = time.time()
    expired = [t for t, v in _SESSION_KEYS.items() if now > v["expires_at"]]
    for t in expired:
        del _SESSION_KEYS[t]

rag_engine = ForensicsRAGEngine()
report_gen = ReportGenerator()
parser = AutopsyParser()


# Pre-load HTML at startup for instant response (prevents tab title flicker)
_HTML_CONTENT = None
_HTML_PATH = None

def _load_html():
    global _HTML_CONTENT, _HTML_PATH
    candidates = [
        ROOT_DIR / "frontend" / "index.html",
        Path(__file__).parent.parent / "frontend" / "index.html",
        Path("../frontend/index.html"),
    ]
    for f in candidates:
        if f.exists():
            _HTML_PATH = f
            with open(f, "r", encoding="utf-8") as fh:
                html = fh.read()
            # Ensure <title> is the very first thing after <head>
            # so browser never has time to show the URL as tab title
            html = html.replace(
                "<head>",
                "<head><title>AUTOPSY SIM - Digital Forensics Bureau</title>"
            , 1)
            _HTML_CONTENT = html
            print(f"[App] Frontend loaded from {f}")
            return
    print("[App] WARNING: frontend/index.html not found")

_load_html()

@app.get("/")
def root():
    from fastapi.responses import HTMLResponse
    if _HTML_CONTENT:
        return HTMLResponse(
            content=_HTML_CONTENT,
            status_code=200,
            headers={
                "Cache-Control": "no-store",
                "X-Content-Type-Options": "nosniff",
            }
        )
    return {"status": "running"}

@app.get("/login.html")
def serve_login():
    from fastapi.responses import HTMLResponse
    candidates = [
        ROOT_DIR / "frontend" / "login.html",
        Path(__file__).parent.parent / "frontend" / "login.html",
    ]
    for f in candidates:
        if f.exists():
            with open(f, "r", encoding="utf-8") as fh:
                return HTMLResponse(content=fh.read(), headers={"Cache-Control": "no-store"})
    return root()

@app.get("/index.html")
def serve_index():
    return root()

# ── SESSION KEY ENDPOINTS ─────────────────────────────────────────────────
from fastapi import Header, HTTPException as FHTTPException
from pydantic import BaseModel

class KeyPayload(BaseModel):
    session_token: str
    api_key: str
    key_type: str  # "groq" or "openai"

@app.get("/api/dashboard")
def get_dashboard():
    """Aggregate stats across all jobs for the dashboard."""
    total_artifacts = 0
    suspicious = 0
    media_count = 0
    completed = 0
    failed = 0
    modes = {"quick": 0, "detailed": 0, "interactive": 0}
    for job in jobs.values():
        st = job.get("status","")
        if st == "completed": completed += 1
        elif st == "error": failed += 1
        modes[job.get("analysis_mode","detailed")] = modes.get(job.get("analysis_mode","detailed"),0) + 1
        rp = job.get("report_path")
        if rp:
            try:
                import json as _json
                with open(rp) as rf:
                    rd = _json.load(rf)
                s = rd.get("summary", {})
                total_artifacts += s.get("total_artifacts", 0)
                suspicious += s.get("suspicious_events", 0)
                media_count += s.get("media_count", 0)
            except Exception:
                pass
    return {
        "total_jobs":       len(jobs),
        "completed_jobs":   completed,
        "failed_jobs":      failed,
        "total_artifacts":  total_artifacts,
        "suspicious_events":suspicious,
        "media_count":      media_count,
        "analysis_modes":   modes,
        "recent_audit":     list(reversed(_audit_log[-5:])),
    }

@app.get("/api/timeline/{job_id}")
def get_timeline(job_id: str, request: Request):
    """Return chronologically sorted normalized events with full traceability."""
    if not _check_rate(request):
        raise HTTPException(status_code=429, detail="Too many requests.")
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    if job.get("status") != "completed":
        raise HTTPException(status_code=400, detail="Job not yet completed")
    # Primary: read from in-memory RAG store (populated during analysis)
    store  = rag_engine.case_data_store.get(job_id, {})
    parsed = store.get("parsed_data", {})
    events = list(parsed.get("normalized_events", []))

    # Fallback: read from saved report JSON on disk (survives restarts)
    if not events and job.get("report_path"):
        try:
            report_json = str(job["report_path"]).replace(".pdf", ".json")
            with open(report_json, "r", encoding="utf-8") as _f:
                _rd = json.load(_f)
            events = list(_rd.get("timeline", []))
            parsed = {"source_file": _rd.get("case_info",{}).get("case_name",""),
                      "file_hash": ""}
        except Exception:
            pass
    # Add media event if uploaded file is media
    fname = job.get("filename", "")
    ext = Path(fname).suffix.lower() if fname else ""
    IMAGE_EXTS = {".jpg",".jpeg",".png",".gif",".bmp",".webp"}
    AUDIO_EXTS = {".mp3",".wav",".aac",".m4a",".ogg",".flac"}
    VIDEO_EXTS = {".mp4",".avi",".mov",".mkv",".wmv",".webm"}
    if ext in IMAGE_EXTS | AUDIO_EXTS | VIDEO_EXTS:
        mtype = "MEDIA_IMAGE" if ext in IMAGE_EXTS else ("MEDIA_AUDIO" if ext in AUDIO_EXTS else "MEDIA_VIDEO")
        events.append({
            "event_type": mtype, "timestamp": job.get("created_at",""),
            "source": fname, "source_row": None,
            "record_ref": fname, "description": f"Media file: {fname}",
            "artifact_id": f"media_{job_id}", "confidence": "High",
            "conf_reason": "User-uploaded media file", "category": "media",
            "raw_attrs": {}, "media_url": f"/api/media-file/{job_id}"
        })
    def _sort_key(e):
        ts = e.get("timestamp","")
        return ts if ts and ts != "Unknown" else "9999"
    events.sort(key=_sort_key)
    return {
        "job_id": job_id, "case_name": job.get("case_name",""),
        "total": len(events), "events": events,
        "source_file": parsed.get("source_file",""),
        "file_hash": parsed.get("file_hash",""),
    }

# ── AUTHENTICATION SYSTEM ────────────────────────────────────────────────
# Passwords stored as PBKDF2-SHA256 (260k iterations) — never plain text
# Format: salt_hex:hash_hex
import hashlib as _hashlib, hmac as _hmac, secrets as _secrets_auth, re as _re

# Password policy constants
_PW_MIN_LEN    = 8
_PW_RE_UPPER   = _re.compile(r'[A-Z]')
_PW_RE_LOWER   = _re.compile(r'[a-z]')
_PW_RE_DIGIT   = _re.compile(r'[0-9]')
_PW_RE_SYMBOL  = _re.compile(r'[^A-Za-z0-9]')

def _validate_password_strength(pw: str):
    """Returns (ok: bool, reason: str)"""
    if len(pw) < _PW_MIN_LEN:
        return False, f"Password must be at least {_PW_MIN_LEN} characters"
    if not _PW_RE_UPPER.search(pw):
        return False, "Password must contain at least one uppercase letter"
    if not _PW_RE_LOWER.search(pw):
        return False, "Password must contain at least one lowercase letter"
    if not _PW_RE_DIGIT.search(pw):
        return False, "Password must contain at least one digit"
    if not _PW_RE_SYMBOL.search(pw):
        return False, "Password must contain at least one special character"
    return True, "OK"

def _hash_password(password: str, salt: str = None) -> str:
    if salt is None:
        salt = _secrets_auth.token_hex(32)
    h = _hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 260000)
    return f"{salt}:{h.hex()}"

def _verify_password(password: str, stored_hash: str) -> bool:
    try:
        salt, _ = stored_hash.split(':', 1)
        candidate = _hash_password(password, salt)
        return _hmac.compare_digest(candidate, stored_hash)
    except Exception:
        return False

# User registry — passwords as PBKDF2 hashes (never plain text)
# Default passwords (strong) — admin can change via /api/auth/change-password
_USER_DB = {
    'admin': {
        'hash':         '9287b7bb9c5019fbb75c1fcb046b2f57dcf4f77163fc2d3882a34173efb9d073:b2ff033373bffa73749b3e355bbd9f8cfd2d352def2127b41cf66b8c16f1e966',
        'role':         'admin',
        'label':        'Administrator',
        'allowedCases': None,
        'canUpload':    True, 'canQuery': True, 'canReport': True,
        'defaultCase':  None,
    },
    'rodriguez': {
        'hash':         'f0d5f331a567897c4c46887e50bdba043a9bb89931d7bcc11ceddedd45a89619:34d158ab39e29889e2dc21375a9ebc71e9546df12aee44525e3f720f11130387',
        'role':         'analyst',
        'label':        'Agent M. Rodriguez',
        'allowedCases': ['insider','CY-2024-0089'],
        'canUpload':    True, 'canQuery': True, 'canReport': True,
        'defaultCase':  {'name':'Operation Insider Threat','number':'CY-2024-0089',
                         'analyst':'Agent M. Rodriguez','dept':'Digital Forensics Lab'},
    },
    'patel': {
        'hash':         '3eee5ef44b11c29a4a70b219c7e67f8dea9264c4103855a49355b971e36a4f8a:efdac33ce71950fd4cbbb5ae6212166933f87c7ee4cc6958daaa6bfa5677cc54',
        'role':         'analyst',
        'label':        'Agent K. Patel',
        'allowedCases': ['darkweb','CY-2024-0090'],
        'canUpload':    True, 'canQuery': True, 'canReport': True,
        'defaultCase':  {'name':'Operation Dark Web','number':'CY-2024-0090',
                         'analyst':'Agent K. Patel','dept':'Digital Forensics Lab'},
    },
    'viewer': {
        'hash':         '4c55cf6e670d18b6068cc79f6140069215d0e4e67b1257875d1bc49fc1ea6fdd:e379af6c38417105a577669a00df81afa2fa8265d591431dcf1f939253f7a245',
        'role':         'viewer',
        'label':        'Viewer',
        'allowedCases': None,
        'canUpload':    False, 'canQuery': False, 'canReport': True,
        'defaultCase':  None,
    },
}

# Login attempt limiting: ip -> {count, locked_until}
_LOGIN_ATTEMPTS: dict = {}
_MAX_ATTEMPTS   = 5
_LOCKOUT_SEC    = 300   # 5 minutes

def _check_login_lockout(ip: str):
    """Returns (allowed: bool, remaining_seconds: int)"""
    entry = _LOGIN_ATTEMPTS.get(ip, {})
    locked_until = entry.get('locked_until', 0)
    if time.time() < locked_until:
        return False, int(locked_until - time.time())
    return True, 0

def _record_login_failure(ip: str):
    entry = _LOGIN_ATTEMPTS.setdefault(ip, {'count': 0, 'locked_until': 0})
    entry['count'] += 1
    if entry['count'] >= _MAX_ATTEMPTS:
        entry['locked_until'] = time.time() + _LOCKOUT_SEC
        entry['count'] = 0
        print(f"[AUTH] Account locked for IP {ip} for {_LOCKOUT_SEC}s")

def _record_login_success(ip: str):
    _LOGIN_ATTEMPTS.pop(ip, None)

# Server-side session store: token -> {username, role, created_at, last_activity}
_AUTH_SESSIONS: dict = {}
_SESSION_INACTIVITY = 1800   # 30 min

def _create_auth_session(username: str, user_data: dict) -> str:
    token = _secrets_auth.token_urlsafe(48)
    _AUTH_SESSIONS[token] = {
        'username':      username,
        'role':          user_data['role'],
        'label':         user_data['label'],
        'allowedCases':  user_data['allowedCases'],
        'canUpload':     user_data['canUpload'],
        'canQuery':      user_data['canQuery'],
        'canReport':     user_data['canReport'],
        'defaultCase':   user_data.get('defaultCase'),
        'created_at':    time.time(),
        'last_activity': time.time(),
    }
    return token

def _get_auth_session(token: str):
    if not token:
        return None
    sess = _AUTH_SESSIONS.get(token)
    if not sess:
        return None
    if time.time() - sess['last_activity'] > _SESSION_INACTIVITY:
        del _AUTH_SESSIONS[token]
        return None
    sess['last_activity'] = time.time()
    return sess

def _destroy_auth_session(token: str):
    _AUTH_SESSIONS.pop(token, None)

def _purge_expired_sessions():
    now = time.time()
    expired = [t for t, s in _AUTH_SESSIONS.items()
               if now - s['last_activity'] > _SESSION_INACTIVITY]
    for t in expired:
        del _AUTH_SESSIONS[t]

# ── CSRF PROTECTION ───────────────────────────────────────────────────────
# Double-Submit Cookie pattern:
#  Step 1: GET /api/auth/csrf  → server sets csrf_token cookie + returns token in JSON
#  Step 2: Every state-changing request must send X-CSRF-Token header matching the cookie
# HttpOnly=False on CSRF cookie so JS can read it; session cookie stays HttpOnly

_CSRF_TOKENS: dict = {}   # token -> expiry

def _generate_csrf() -> str:
    token = _secrets_auth.token_urlsafe(32)
    _CSRF_TOKENS[token] = time.time() + 3600   # 1-hour validity
    return token

def _validate_csrf(request: Request) -> bool:
    header_token = request.headers.get("X-CSRF-Token","")
    cookie_token = request.cookies.get("dfr_csrf","")
    if not header_token or not cookie_token:
        return False
    # Must match AND must be a known token (not forged)
    if not _hmac.compare_digest(header_token, cookie_token):
        return False
    exp = _CSRF_TOKENS.get(header_token, 0)
    if time.time() > exp:
        _CSRF_TOKENS.pop(header_token, None)
        return False
    return True

def _purge_csrf():
    now = time.time()
    expired = [t for t, exp in list(_CSRF_TOKENS.items()) if now > exp]
    for t in expired:
        _CSRF_TOKENS.pop(t, None)

# ── AUTH API ENDPOINTS ─────────────────────────────────────────────────────
from fastapi.responses import JSONResponse

class LoginPayload(BaseModel):
    username: str
    password: str

@app.get("/api/auth/csrf")
async def get_csrf_token(request: Request):
    """Issue a CSRF token. Call this before any state-changing request."""
    _purge_csrf()
    token = _generate_csrf()
    resp  = JSONResponse(content={"csrf_token": token})
    resp.set_cookie(
        key="dfr_csrf",
        value=token,
        httponly=False,          # JS must read this to send in header
        samesite="strict",
        max_age=3600,
        path="/",
        secure=False,            # localhost — set True in production (HTTPS)
    )
    return resp

@app.post("/api/auth/login")
async def auth_login(payload: LoginPayload, request: Request):
    _purge_expired_sessions()
    ip = getattr(request.client, "host", "unknown")

    # CSRF validation
    if not _validate_csrf(request):
        return JSONResponse(status_code=403,
            content={"error": "Invalid or missing CSRF token. Refresh the page and try again."})

    # Rate check for login attempts
    allowed, remaining = _check_login_lockout(ip)
    if not allowed:
        return JSONResponse(
            status_code=429,
            content={"error": f"Account temporarily locked. Try again in {remaining}s.",
                     "locked": True, "remaining": remaining}
        )

    username = (payload.username or "").strip().lower()
    password = payload.password or ""

    user = _USER_DB.get(username)
    if not user or not _verify_password(password, user['hash']):
        _record_login_failure(ip)
        attempts_left = _MAX_ATTEMPTS - _LOGIN_ATTEMPTS.get(ip, {}).get('count', 0)
        _audit("system", "LOGIN_FAILED", f"user={username} | ip={ip}")
        return JSONResponse(
            status_code=401,
            content={"error": "Invalid username or password.",
                     "attempts_left": max(0, attempts_left)}
        )

    _record_login_success(ip)
    token = _create_auth_session(username, user)
    _audit(username, "LOGIN_OK", f"ip={ip}")

    resp = JSONResponse(content={
        "ok":           True,
        "username":     username,
        "role":         user['role'],
        "label":        user['label'],
        "allowedCases": user['allowedCases'],
        "canUpload":    user['canUpload'],
        "canQuery":     user['canQuery'],
        "canReport":    user['canReport'],
        "defaultCase":  user.get('defaultCase'),
    })
    # Secure HttpOnly cookie — not accessible from JS
    resp.set_cookie(
        key="dfr_session",
        value=token,
        httponly=True,           # JS cannot access — XSS-safe
        samesite="strict",       # CSRF-safe — no cross-site sends
        max_age=_SESSION_INACTIVITY,
        path="/",
        secure=False,            # localhost — change to True for HTTPS/production
    )
    # Rotate CSRF token after successful login
    new_csrf = _generate_csrf()
    resp.set_cookie(
        key="dfr_csrf",
        value=new_csrf,
        httponly=False,
        samesite="strict",
        max_age=3600,
        path="/",
        secure=False,
    )
    return resp

@app.post("/api/auth/logout")
async def auth_logout(request: Request):
    if not _validate_csrf(request):
        return JSONResponse(status_code=403, content={"error": "Invalid CSRF token."})
    token = request.cookies.get("dfr_session","")
    if token:
        _destroy_auth_session(token)
        _audit("system","LOGOUT",f"session={token[:8]}...")
    resp = JSONResponse(content={"ok": True})
    resp.delete_cookie("dfr_session", path="/")
    return resp

@app.get("/api/auth/me")
async def auth_me(request: Request):
    """Check current session — called on every page load."""
    _purge_expired_sessions()
    token = request.cookies.get("dfr_session","")
    sess  = _get_auth_session(token)
    if not sess:
        return JSONResponse(status_code=401, content={"authenticated": False})
    return JSONResponse(content={"authenticated": True, **{k:v for k,v in sess.items()
                                  if k not in ('created_at','last_activity')}})

@app.post("/api/auth/ping")
async def auth_ping(request: Request):
    """Refresh session on user activity."""
    token = request.cookies.get("dfr_session","")
    sess  = _get_auth_session(token)
    if not sess:
        return JSONResponse(status_code=401, content={"ok": False})
    return JSONResponse(content={"ok": True})

@app.post("/api/auth/register")
async def register_user(payload: dict, request: Request):
    """Create a new user account. Anyone can self-register as a viewer.
    Role defaults to 'viewer'. Admin can promote via /api/auth/admin/set-role."""
    _purge_csrf()
    if not _validate_csrf(request):
        return JSONResponse(status_code=403, content={"error": "Invalid CSRF token."})

    username    = (payload.get("username","") or "").strip().lower()
    password    = payload.get("password","") or ""
    display     = (payload.get("display_name","") or "").strip() or username.capitalize()

    # Username validation
    if not username:
        return JSONResponse(status_code=400, content={"error": "Username is required."})
    if len(username) < 3 or len(username) > 20:
        return JSONResponse(status_code=400, content={"error": "Username must be 3–20 characters."})
    import re as _re2
    if not _re2.match(r'^[a-z0-9_]+$', username):
        return JSONResponse(status_code=400,
            content={"error": "Username may only contain lowercase letters, digits, and underscores."})
    RESERVED = {'admin','root','system','anonymous','guest','null','undefined'}
    if username in RESERVED:
        return JSONResponse(status_code=400, content={"error": "That username is reserved."})
    if username in _USER_DB:
        return JSONResponse(status_code=409, content={"error": "Username already taken."})

    # Password validation
    ok, reason = _validate_password_strength(password)
    if not ok:
        return JSONResponse(status_code=400, content={"error": reason})

    # Create user with viewer role
    ip = getattr(request.client, "host", "unknown")
    _USER_DB[username] = {
        "hash":         _hash_password(password),
        "role":         "viewer",
        "label":        display,
        "allowedCases": None,
        "canUpload":    False,
        "canQuery":     False,
        "canReport":    True,
        "defaultCase":  None,
    }
    _audit("system", "USER_REGISTERED", f"username={username} | ip={ip}")
    return JSONResponse(content={"ok": True, "username": username,
                                  "role": "viewer",
                                  "message": "Account created. You can now log in."})

@app.post("/api/auth/admin/set-role")
async def admin_set_role(payload: dict, request: Request):
    """Admin-only: promote/demote a user's role."""
    if not _validate_csrf(request):
        return JSONResponse(status_code=403, content={"error": "Invalid CSRF token."})
    token = request.cookies.get("dfr_session","")
    sess  = _get_auth_session(token)
    if not sess or sess.get("role") != "admin":
        return JSONResponse(status_code=403, content={"error": "Admin access required."})
    target   = (payload.get("username","") or "").strip().lower()
    new_role = (payload.get("role","") or "").strip().lower()
    if target not in _USER_DB:
        return JSONResponse(status_code=404, content={"error": "User not found."})
    if new_role not in ("admin","analyst","viewer"):
        return JSONResponse(status_code=400, content={"error": "Invalid role."})
    _USER_DB[target]["role"]      = new_role
    _USER_DB[target]["canUpload"] = new_role in ("admin","analyst")
    _USER_DB[target]["canQuery"]  = new_role in ("admin","analyst")
    _audit(sess["username"], "ROLE_CHANGED", f"target={target} | new_role={new_role}")
    return JSONResponse(content={"ok": True})

@app.post("/api/auth/change-password")
async def change_password(payload: dict, request: Request):
    """Change own password — must meet strength requirements."""
    if not _validate_csrf(request):
        return JSONResponse(status_code=403, content={"error": "Invalid CSRF token."})
    token = request.cookies.get("dfr_session","")
    sess  = _get_auth_session(token)
    if not sess:
        return JSONResponse(status_code=401, content={"error":"Not authenticated"})
    username    = sess['username']
    old_pw      = payload.get('old_password','')
    new_pw      = payload.get('new_password','')
    user        = _USER_DB.get(username)
    if not user or not _verify_password(old_pw, user['hash']):
        return JSONResponse(status_code=403, content={"error":"Current password incorrect"})
    ok, reason = _validate_password_strength(new_pw)
    if not ok:
        return JSONResponse(status_code=400, content={"error": reason})
    _USER_DB[username]['hash'] = _hash_password(new_pw)
    _audit(username, "PASSWORD_CHANGED", f"ip={getattr(request.client,'host','?')}")
    return JSONResponse(content={"ok": True})

# ── RATE LIMITING ────────────────────────────────────────────────────────

import collections as _col
_rate_store = _col.defaultdict(list)  # ip -> [timestamps]
_RATE_LIMIT = 60   # max requests per minute per IP

def _check_rate(request) -> bool:
    ip = getattr(request.client, "host", "unknown")
    now = time.time()
    # Keep only last 60 seconds
    _rate_store[ip] = [t for t in _rate_store[ip] if now - t < 60]
    if len(_rate_store[ip]) >= _RATE_LIMIT:
        return False
    _rate_store[ip].append(now)
    return True

# ── PER-JOB AUDIT LOG ────────────────────────────────────────────────────
@app.get("/api/job-audit/{job_id}")
def get_job_audit(job_id: str):
    """Return audit trail for a specific job — who did what when."""
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    entries = job_audit.get(job_id, [])
    job = jobs[job_id]
    # Enrich with job metadata
    return {
        "job_id":       job_id,
        "case_name":    job.get("case_name",""),
        "analyst":      job.get("analyst_name",""),
        "created_at":   job.get("created_at",""),
        "sha256":       job.get("sha256",""),
        "audit_trail":  entries,
        "total_events": len(entries),
    }

# ── EXPORT ENDPOINTS ──────────────────────────────────────────────────────
@app.get("/api/export/timeline/{job_id}")
def export_timeline(job_id: str):
    """Export timeline as JSON for download."""
    if job_id not in jobs: raise HTTPException(404, "Job not found")
    store = rag_engine.case_data_store.get(job_id, {})
    parsed = store.get("parsed_data", {})
    events = parsed.get("normalized_events", [])
    return {
        "export_type":  "timeline",
        "job_id":       job_id,
        "case_name":    jobs[job_id].get("case_name",""),
        "generated_at": datetime.now().isoformat(),
        "events":       events,
        "total":        len(events),
    }

@app.get("/api/export/artifacts/{job_id}")
def export_artifacts(job_id: str):
    """Export full artifact list as JSON."""
    if job_id not in jobs: raise HTTPException(404, "Job not found")
    store = rag_engine.case_data_store.get(job_id, {})
    parsed = store.get("parsed_data", {})
    return {
        "export_type":  "artifacts",
        "job_id":       job_id,
        "case_name":    jobs[job_id].get("case_name",""),
        "generated_at": datetime.now().isoformat(),
        "summary":      parsed.get("summary",{}),
        "artifacts":    parsed.get("artifacts",[]),
        "normalized":   parsed.get("normalized_events",[]),
    }

@app.get("/api/export/queries/{job_id}")
def export_queries(job_id: str):
    """Export query log for a job."""
    if job_id not in jobs: raise HTTPException(404, "Job not found")
    entries = [e for e in job_audit.get(job_id,[]) if e.get("action") == "QUERY_ASKED"]
    return {
        "export_type":  "query_log",
        "job_id":       job_id,
        "case_name":    jobs[job_id].get("case_name",""),
        "generated_at": datetime.now().isoformat(),
        "queries":      entries,
        "total":        len(entries),
    }

@app.get("/api/audit")
def get_audit_log(session_token: str = ""):
    """Return audit log — only for authenticated sessions."""
    with _audit_lock:
        return {"audit_log": list(reversed(_audit_log[-100:]))}

@app.post("/api/validate-key")
def validate_api_key(payload: KeyPayload):
    """Test the key against the real API before storing it."""
    _purge_expired_keys()
    if not payload.api_key or not payload.session_token:
        return {"valid": False, "error": "Missing fields"}
    key = payload.api_key.strip()
    key_type = payload.key_type if payload.key_type in ("groq","openai") else "groq"
    try:
        if key_type == "groq":
            try:
                from groq import Groq
                client = Groq(api_key=key)
                # Minimal test call
                client.chat.completions.create(
                    model="llama-3.3-70b-versatile",
                    messages=[{"role":"user","content":"hi"}],
                    max_tokens=1
                )
                valid = True
            except Exception as e:
                err = str(e)
                if "401" in err or "invalid" in err.lower() or "api key" in err.lower() or "auth" in err.lower():
                    return {"valid": False, "error": "Invalid API key"}
                # Network or other error - treat as valid but warn
                valid = True
        elif key_type == "openai":
            try:
                from openai import OpenAI
                client = OpenAI(api_key=key)
                client.models.list()
                valid = True
            except Exception as e:
                err = str(e)
                if "401" in err or "invalid" in err.lower() or "api key" in err.lower() or "auth" in err.lower():
                    return {"valid": False, "error": "Invalid API key"}
                valid = True
        else:
            return {"valid": False, "error": "Unknown key type"}
        # If valid, store it
        if valid:
            _store_session_key(payload.session_token, key, key_type)
        return {"valid": valid}
    except Exception as e:
        return {"valid": False, "error": str(e)}

@app.post("/api/set-key")
def set_api_key(payload: KeyPayload):
    _purge_expired_keys()
    if not payload.api_key or not payload.session_token:
        raise FHTTPException(status_code=400, detail="Missing fields")
    key_type = payload.key_type if payload.key_type in ("groq","openai") else "groq"
    _store_session_key(payload.session_token, payload.api_key, key_type)
    return {"status": "stored"}

@app.post("/api/clear-key")
def clear_api_key(payload: dict):
    token = payload.get("session_token","")
    _clear_session_key(token)
    return {"status": "cleared"}

@app.get("/api/key-status")
def key_status(session_token: str = ""):
    _purge_expired_keys()
    entry = _SESSION_KEYS.get(session_token)
    if not entry or time.time() > entry["expires_at"]:
        return {"active": False}
    remaining = int(entry["expires_at"] - time.time())
    return {"active": True, "key_type": entry["key_type"], "remaining_seconds": remaining}

@app.post("/api/refresh-session")
def refresh_session(payload: dict):
    token = payload.get("session_token","")
    entry = _SESSION_KEYS.get(token)
    if entry:
        entry["expires_at"] = time.time() + _SESSION_TIMEOUT
    return {"status": "ok"}




@app.post("/api/upload")
async def upload_forensic_log(
    request: Request,
    file: UploadFile = File(...),
    case_name: str = Form("Unknown Case"),
    analyst_name: str = Form("Unknown Analyst"),
    case_number: str = Form("CASE-001"),
    session_token: str = Form(""),
    department: str = Form("Digital Forensics Lab"),
    analysis_mode: str = Form("detailed"),
):
    from autopsy_parser import FileValidationError

    # ── Rate limiting ─────────────────────────────────────────
    if not _check_rate(request):
        raise HTTPException(status_code=429, detail="Too many requests. Please wait before uploading again.")

    # ── Validate extension before saving ─────────────────────
    allowed_exts = {".xml", ".csv", ".json", ".log", ".txt",
                    ".jpg", ".jpeg", ".png", ".mp4", ".avi", ".mov",
                    ".mp3", ".wav", ".aac", ".m4a"}
    fname = file.filename or "unknown"
    ext = Path(fname).suffix.lower()
    if ext not in allowed_exts:
        _audit(analyst_name, "UPLOAD_REJECTED", f"Unsupported type: {ext} | file: {fname}")
        raise HTTPException(status_code=400, detail=f"Unsupported file type '{ext}'")

    job_id = str(uuid.uuid4())
    job_dir = UPLOAD_DIR / job_id
    job_dir.mkdir(exist_ok=True)

    file_path = job_dir / fname
    content = await file.read()

    if len(content) == 0:
        _audit(analyst_name, "UPLOAD_REJECTED", f"Empty file: {fname}")
        raise HTTPException(status_code=400, detail="Uploaded file is empty")
    if len(content) > 50 * 1024 * 1024:
        _audit(analyst_name, "UPLOAD_REJECTED", f"File too large: {fname}")
        raise HTTPException(status_code=400, detail="File too large (max 50MB)")

    with open(file_path, "wb") as f:
        f.write(content)

    # Compute SHA-256 for file integrity proof
    import hashlib as _hl
    sha256 = _hl.sha256(content).hexdigest().upper()

    jobs[job_id] = {
        "id": job_id,
        "status": "uploaded",
        "file": str(file_path),
        "filename": fname,
        "case_name": case_name,
        "analyst_name": analyst_name,
        "case_number": case_number,
        "department": department,
        "created_at": datetime.now().isoformat(),
        "report_path": None,
        "error": None,
        "session_token": session_token,
        "analysis_mode": analysis_mode,
        "sha256": sha256,
    }

    _audit(analyst_name, "CASE_CREATED", f"case={case_name} | analyst={analyst_name}")
    _job_audit(job_id, analyst_name, "CASE_CREATED", f"case={case_name}")
    _job_audit(job_id, analyst_name, "EVIDENCE_UPLOADED", f"file={fname} | sha256={sha256[:16]}...")

    return {"job_id": job_id, "status": "uploaded", "message": "File uploaded successfully"}


@app.post("/api/process/{job_id}")
async def process_forensic_log(job_id: str, background_tasks: BackgroundTasks):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    jobs[job_id]["status"] = "processing"
    background_tasks.add_task(run_pipeline, job_id)
    return {"job_id": job_id, "status": "processing"}


@app.get("/api/status/{job_id}")
def get_status(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    return jobs[job_id]


@app.get("/api/report/{job_id}")
def download_report(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail=f"Report not ready. Status: {job['status']}")
    report_path = job["report_path"]
    if not report_path or not Path(report_path).exists():
        raise HTTPException(status_code=404, detail="Report file not found")
    return FileResponse(
        report_path,
        media_type="application/pdf",
        filename=f"forensics_report_{job_id[:8]}.pdf"
    )


@app.get("/api/report-preview/{job_id}")
def preview_report(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail=f"Report not ready. Status: {job['status']}")
    preview_path = Path(str(job["report_path"]).replace(".pdf", ".json"))
    if preview_path.exists():
        with open(preview_path) as f:
            return json.load(f)
    return {"error": "Preview not available"}


@app.get("/api/jobs")
def list_jobs():
    return list(jobs.values())


@app.post("/api/query/{job_id}")
async def query_case(request: Request, job_id: str, query: dict):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    if job["status"] != "completed":
        raise HTTPException(status_code=400, detail="Case not fully processed yet")
    question = query.get("question", "")
    if not question:
        raise HTTPException(status_code=400, detail="Question is required")
    # Use session API key if provided
    session_token = query.get("session_token", "")
    if session_token:
        session_key, key_type = _get_session_key(session_token)
        if session_key:
            rag_engine.set_runtime_key(session_key, key_type)
    answer = rag_engine.query(job_id, question)
    analyst_q = job.get("analyst_name","?")
    _audit(analyst_q, "AI_QUERY", f"job={job_id} | q={question[:80]}")
    _job_audit(job_id, analyst_q, "QUERY_ASKED", f"q={question[:120]}")
    return {"question": question, "answer": answer, "job_id": job_id}


@app.get("/api/media/{job_id}")
def get_media_info(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    filename = job["filename"].lower()

    IMAGE_EXTS = {'.jpg', '.jpeg', '.png', '.gif', '.bmp', '.webp', '.tiff'}
    AUDIO_EXTS = {'.mp3', '.wav', '.aac', '.m4a', '.ogg', '.flac', '.opus', '.wma'}
    VIDEO_EXTS = {'.mp4', '.avi', '.mov', '.mkv', '.wmv', '.flv', '.webm', '.m4v'}

    ext = '.' + filename.rsplit('.', 1)[-1] if '.' in filename else ''

    if ext in IMAGE_EXTS:
        media_type = 'image'
    elif ext in AUDIO_EXTS:
        media_type = 'audio'
    elif ext in VIDEO_EXTS:
        media_type = 'video'
    else:
        media_type = 'none'

    file_path = Path(job["file"])
    file_size = file_path.stat().st_size if file_path.exists() else 0
    size_str = f"{file_size // (1024*1024)} MB" if file_size > 1024*1024 else f"{file_size // 1024} KB"

    return {
        "job_id": job_id,
        "filename": job["filename"],
        "media_type": media_type,
        "case_name": job["case_name"],
        "case_number": job["case_number"],
        "analyst_name": job["analyst_name"],
        "created_at": job["created_at"],
        "size": size_str,
        "file_url": f"/api/media-file/{job_id}",
        "status": job["status"]
    }


@app.get("/api/media-file/{job_id}")
def serve_media_file(job_id: str):
    if job_id not in jobs:
        raise HTTPException(status_code=404, detail="Job not found")
    job = jobs[job_id]
    file_path = Path(job["file"])
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")

    filename = job["filename"].lower()
    ext = '.' + filename.rsplit('.', 1)[-1] if '.' in filename else ''

    mime_map = {
        '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
        '.gif': 'image/gif', '.webp': 'image/webp',
        '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.aac': 'audio/aac',
        '.m4a': 'audio/mp4', '.ogg': 'audio/ogg', '.opus': 'audio/opus',
        '.mp4': 'video/mp4', '.avi': 'video/x-msvideo', '.mov': 'video/quicktime',
        '.mkv': 'video/x-matroska', '.webm': 'video/webm',
    }
    media_type = mime_map.get(ext, 'application/octet-stream')

    return FileResponse(str(file_path), media_type=media_type, filename=job["filename"])




@app.get("/api/sample-file/{filename}")
def serve_sample_file(filename: str):
    # Security: strip any path traversal
    filename = Path(filename).name
    sample_dir = ROOT_DIR / "sample_data"
    file_path = sample_dir / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail=f"Sample file not found: {filename}")
    ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
    mime_map = {
        "jpg": "image/jpeg", "jpeg": "image/jpeg", "png": "image/png",
        "gif": "image/gif", "webp": "image/webp",
        "mp3": "audio/mpeg", "wav": "audio/wav", "aac": "audio/aac",
        "m4a": "audio/mp4", "ogg": "audio/ogg",
        "mp4": "video/mp4", "avi": "video/x-msvideo",
        "mov": "video/quicktime", "webm": "video/webm",
    }
    media_type = mime_map.get(ext, "application/octet-stream")
    import os
    # Try multiple locations to handle different working directory scenarios
    candidates = [
        file_path,
        Path(__file__).parent / "sample_data" / Path(filename).name,
        Path("sample_data") / Path(filename).name,
    ]
    resolved = None
    for c in candidates:
        if c.exists():
            resolved = c
            break
    if resolved is None:
        raise HTTPException(status_code=404, detail=f"File not found in any sample_data location: {filename}")
    file_size = os.path.getsize(str(resolved))
    from fastapi.responses import StreamingResponse
    def iterfile():
        with open(str(resolved), "rb") as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                yield chunk
    headers = {
        "Cache-Control": "no-cache, no-store, must-revalidate",
        "Pragma": "no-cache",
        "Expires": "0",
        "Content-Length": str(file_size),
        "Accept-Ranges": "bytes",
        "Content-Disposition": f"inline; filename={filename}",
    }
    return StreamingResponse(iterfile(), media_type=media_type, headers=headers)


def run_pipeline(job_id: str):
    try:
        job = jobs[job_id]
        file_path = job["file"]
        analysis_mode = job.get("analysis_mode", "detailed")
        analyst = job.get("analyst_name", "?")

        _audit(analyst, "PIPELINE_START", f"job={job_id} | mode={analysis_mode}")
        _job_audit(job_id, analyst, "ANALYSIS_STARTED", f"mode={analysis_mode}")

        # Inject session API key if present
        session_token = job.get("session_token", "")
        if session_token:
            session_key, key_type = _get_session_key(session_token)
            if session_key:
                rag_engine.set_runtime_key(session_key, key_type)
                report_gen.set_runtime_key(session_key, key_type)

        jobs[job_id]["status"] = "parsing"
        from autopsy_parser import FileValidationError
        try:
            parsed_data = parser.parse(file_path)
        except FileValidationError as fve:
            jobs[job_id]["status"] = "error"
            jobs[job_id]["error"] = f"File validation failed: {fve}"
            _audit(analyst, "PIPELINE_ERROR", f"job={job_id} | validation: {fve}")
            return

        jobs[job_id]["status"] = "indexing"
        rag_engine.index_case(job_id, parsed_data)

        jobs[job_id]["status"] = "generating"
        report_data = report_gen.generate(
            job_id=job_id,
            parsed_data=parsed_data,
            rag_engine=rag_engine,
            case_info={
                "case_name": job["case_name"],
                "analyst_name": job["analyst_name"],
                "case_number": job["case_number"],
                "department": job["department"],
                "created_at": job["created_at"]
            }
        )

        report_path = str(REPORTS_DIR / f"report_{job_id}.pdf")
        report_json_path = str(REPORTS_DIR / f"report_{job_id}.json")

        report_gen.save_pdf(report_data, report_path)

        with open(report_json_path, "w") as f:
            json.dump(report_data, f, indent=2, default=str)

        jobs[job_id]["status"] = "completed"
        jobs[job_id]["report_path"] = report_path
        _job_audit(job_id, analyst, "REPORT_GENERATED",
                   f"artifacts={parsed_data.get('summary',{}).get('total_artifacts',0)} | "
                   f"high_conf={parsed_data.get('summary',{}).get('high_confidence_events',0)}")

    except Exception as e:
        jobs[job_id]["status"] = "failed"
        jobs[job_id]["error"] = str(e)
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
